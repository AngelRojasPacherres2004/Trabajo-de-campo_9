




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author GAMER
 */
public class Incidente {
    private String fecha;
    private String tipo;
    private String hora;
    private String descripcion;

   
    

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
  
    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Incidente(String fecha, String tipo,String descripcion,String hora) {
        this.fecha = fecha;
        this.tipo = tipo;
        this.hora=hora;
        this.descripcion=descripcion;
    }
    
    
    
     public String getDatosMostrar() {
        return this.tipo +" - HORA: "+this.hora+" -Fecha: "+this.fecha;
    }
}
